CODE 1:
import java.util.*;
class Main{
public static void main(String[] args){
System.out.print("Welcome to Bridgelabz!");
}
}



CODE 2:
import java.util.*;
class Main{
public static void main(String[] args){
Scanner sc= new Scanner(System.in);
float a= sc.nextFloat();
float b= sc.nextFloat();
float c= a+b;
System.out.print(c);
}
}



CODE 3:
import java.util.*;
class Main{
public static void main(String[] args){
Scanner sc= new Scanner(System.in);
float Celsius= sc.nextFloat();
float Fahrenheit= (Celsius*1.8)+32;
System.out.print(Fahrenheit);
}
}



CODE 4:
import java.util.*;
class Main{
public static void main(String[] args){
Scanner sc= new Scanner(System.in);
float radius= sc.nextFloat();
float p= 3.14;
float Area= p*radius*radius;
System.out.print(Area);
}
}



CODE 5:
import java.util.*;
class Main{
public static void main(String[] args){
Scanner sc= new Scanner(System.in);
float radius= sc.nextInt();
float height= sc.nextInt();
float p= 3.14;
float Volume= p*radius*radius*height;
System.out.print(Volume);
}
}



CODE 6:
import java.util.*;
class Main{
public static void main(String[] args){
Scanner sc= new Scanner(System.in);
double principle= sc.nextDouble();
double rate= sc.nextDouble();
double time= sc.nextDouble();
double SI= principle*rate*time*0.01;
System.out.print(SI);
}
}



CODE 7:
import java.util.*;
class Main{
public static void main(String[] args){
Scanner sc= new Scanner(System.in);
double length= sc.nextDouble();
double width= sc.nextDouble();
double perimeter= 2*(length+breadth);
System.out.print(perimeter);
}
}



CODE 8:
import java.util.*;
class Main{
public static void main(String[] args){
Scanner sc= new Scanner(System.in);
int a= sc.nextInt();
int b= sc.nextInt();
int expo= Math.pow(a,b);
System.out.print(expo);
}
}



CODE 9:
import java.util.*;
class Main{
public static void main(String[] args){
Scanner sc= new Scanner(System.in);
int a= sc.nextInt();
int b= sc.nextInt();
int c= sc.nextInt();
int numerator= a+b+c;
int average= numerator/3;
System.out.print(average);
}
}



CODE 10:
import java.util.*;
class Main{
public static void main(String[] args){
Scanner sc= new Scanner(System.in);
double km= sc.nextDouble();
double miles= km*0.621371;
System.out.print(miles);
}
}
